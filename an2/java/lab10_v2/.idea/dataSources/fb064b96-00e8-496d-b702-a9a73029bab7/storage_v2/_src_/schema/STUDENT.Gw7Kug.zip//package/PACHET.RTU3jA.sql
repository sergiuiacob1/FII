create PACKAGE pachet IS

     TYPE bursa_studenti IS RECORD(
      id_student studenti.id%TYPE,
      procentaj INT
    );
    bursa bursa_studenti;

    TYPE lista IS VARRAY(100) OF bursa_studenti;
    lista_studenti lista := lista();

    PROCEDURE marire_bursa(lista_studenti lista);

END pachet;
/


create procedure redo_table (p_fisier IN UTL_FILE.FILE_TYPE, p_nume_tabela in VARCHAR2) as
begin
    export_depending_tables (p_fisier, p_nume_tabela);
    create_table (p_fisier, p_nume_tabela);
    insert_into_table(p_fisier, p_nume_tabela);
end redo_table;
/


create type body om as
    constructor function om (p_nume varchar2, p_prenume varchar2, p_varsta int) return self as result IS
    begin
        nume := p_nume;
        prenume := p_prenume;
        varsta := p_varsta;
        return;
    end;

    member procedure gateste is
    begin
        DBMS_OUTPUT.PUT_LINE ('Am gatit.');
    end gateste;

    member procedure info is 
    begin
        DBMS_OUTPUT.PUT_LINE ('Nume: ' || nume || ', prenume: ' || prenume || ', varsta: ' || varsta || ', sex: ' || sex);
    end info;

    ORDER member function omsort (p_om2 om) return number is
    begin
        IF (self.varsta = p_om2.varsta) THEN return 0; END IF;
        IF (self.varsta < p_om2.varsta) THEN return -1; END IF;
        return 1;
    end omsort;
end;
/


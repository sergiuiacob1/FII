package lab4;

public class InvalidCommandExceptions extends Exception {
    public InvalidCommandExceptions(String err){
        super(err);
    }
}

package lab4;

public class Manual extends Document{

    Manual (String name, String path) throws InvalidYearException, FileNotFoundException {
        super (name, path, 0);
    }
}

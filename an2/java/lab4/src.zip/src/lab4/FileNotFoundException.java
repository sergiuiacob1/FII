package lab4;

public class FileNotFoundException extends Exception{
    public FileNotFoundException (String error){
        super (error);
    }
}

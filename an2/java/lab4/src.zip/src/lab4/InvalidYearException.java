package lab4;

public class InvalidYearException extends Exception {
    public InvalidYearException(String error) {
        super(error);
    }
}
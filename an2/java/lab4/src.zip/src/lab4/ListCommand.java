package lab4;

public class ListCommand {
    public void run(Catalog catalog, String[] arr) {
        catalog.list();
    }
}

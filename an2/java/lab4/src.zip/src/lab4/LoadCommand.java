package lab4;

public class LoadCommand {
    public void check(String[] arr) {
    }

    public void run(Catalog catalog, String[] arr) {
        //catalog.load("catalog.dat");
        //catalog.list();
    }
}

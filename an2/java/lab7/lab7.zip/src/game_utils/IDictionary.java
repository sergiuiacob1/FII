package game_utils;

public interface IDictionary {
    public Boolean containsWord(String str);
}

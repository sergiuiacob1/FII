package game_utils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Bag {
    private static final StringBuilder letters = new StringBuilder();

    Bag() {
        //letter distribution
        for (int i = 0; i < 12; ++i) {
            letters.append('e');
        }
        for (int i = 0; i < 9; ++i) {
            letters.append('a');
            letters.append('i');
        }

        for (int i = 0; i < 8; ++i) {
            letters.append('o');
        }

        for (int i = 0; i < 6; ++i) {
            letters.append('n');
            letters.append('r');
            letters.append('t');
        }

        for (int i = 0; i < 4; ++i) {
            letters.append('l');
            letters.append('s');
            letters.append('u');
            letters.append('d');
        }

        for (int i = 0; i < 3; ++i) {
            letters.append('g');
        }

        for (int i = 0; i < 2; ++i) {
            letters.append('b');
            letters.append('c');
            letters.append('m');
            letters.append('p');
            letters.append('f');
            letters.append('h');
            letters.append('v');
            letters.append('w');
            letters.append('y');
        }

        letters.append('k');
        letters.append('j');
        letters.append('x');
        letters.append('q');
        letters.append('z');
        letters.append(' ');
        letters.append(' ');
    }

    public synchronized List<Character> extractLetters(int howMany) {
        // Replace the dots so that the bag is thread-safe
        Integer randomPos;
        List<Character> extracted = new ArrayList<>();
        for (int i = 0; i < howMany; i++) {
            if (letters.toString().isEmpty()) break;
            randomPos = ThreadLocalRandom.current().nextInt(0, letters.length());
            extracted.add(letters.charAt(randomPos));
            letters.deleteCharAt(randomPos);
        }
        return extracted;
    }
}
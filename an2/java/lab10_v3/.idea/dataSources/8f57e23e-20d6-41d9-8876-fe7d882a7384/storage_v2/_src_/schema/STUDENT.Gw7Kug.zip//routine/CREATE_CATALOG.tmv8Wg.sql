create procedure create_catalog (p_cline IN cursuri%ROWTYPE) as
    v_cursor_id NUMBER;
    v_ok number;
    v_rec_tab     DBMS_SQL.DESC_TAB;
    v_nr_col     NUMBER;
    v_total_coloane     NUMBER;
    v_stud_nume VARCHAR2(100);
    v_stud_prenume VARCHAR2(100);
    v_stud_nr_matricol varchar2(100);
    v_nline note%ROWTYPE;
    v_id INT;
begin
    v_cursor_id  := DBMS_SQL.OPEN_CURSOR;
    DBMS_SQL.PARSE(v_cursor_id , 'drop table catalog_' || p_cline.id || ' cascade constraints', DBMS_SQL.NATIVE);
    v_ok := DBMS_SQL.EXECUTE(v_cursor_id );

    DBMS_SQL.PARSE(v_cursor_id , 'create table catalog_' || p_cline.id || ' ( id int primary key, valoare number(2), data_notare date, nume varchar2(100), prenume varchar2(100), nr_matricol varchar2(10))', DBMS_SQL.NATIVE);
    v_ok := DBMS_SQL.EXECUTE (v_cursor_id);    
    dbms_sql.close_cursor (v_cursor_id);
end create_catalog;
/


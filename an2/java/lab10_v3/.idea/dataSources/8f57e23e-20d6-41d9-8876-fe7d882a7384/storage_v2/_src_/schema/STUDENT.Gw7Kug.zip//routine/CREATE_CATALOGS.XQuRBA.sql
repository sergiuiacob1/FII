create procedure create_catalogs as
    v_cline cursuri%ROWTYPE;
begin
    for v_cline in (select * from cursuri) loop
        create_catalog (v_cline);
    end loop;

    insert_note();
end create_catalogs;
/


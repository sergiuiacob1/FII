create function add_om(p_nume varchar2, p_prenume varchar2, p_varsta int) return int as
    v_nextId INT;
    v_cnt number;
begin
    select count(*) into v_cnt from obj_om;
    if (v_cnt = 0) then
        v_nextId := 0;
    else
        select max(id) into v_nextId from obj_om;
    end if;

    v_nextId := v_nextId + 1;
    insert into obj_om values (v_nextId, new om (p_nume, p_prenume, p_varsta));
    COMMIT;
    return v_nextId;
end add_om;
/


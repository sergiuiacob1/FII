create procedure redo_this_table_as_well (p_fisier IN UTL_FILE.FILE_TYPE, p_nume_tabela in VARCHAR2) as
begin
    create_table (p_fisier, p_nume_tabela);
    insert_into_table(p_fisier, p_nume_tabela);
end redo_this_table_as_well;
/


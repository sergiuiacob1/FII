create PACKAGE BODY pachet IS
    
    v_bursa studenti.bursa%TYPE;
    v_newBursa studenti.bursa%TYPE;
    v_id studenti.id%TYPE;
    v_nume studenti.nume%TYPE;
--    v_istoric_bursa NUMBER;

     PROCEDURE marire_bursa(lista_studenti lista)
      IS BEGIN

           FOR i IN lista_studenti.FIRST..lista_studenti.LAST LOOP
              SELECT bursa into v_bursa from studenti
              where id = lista_studenti(i).id_student;
              IF v_bursa IS NULL THEN
--                DBMS_OUTPUT.PUT_LINE(i||' - NULL');

                   v_newBursa := 100 + lista_studenti(i).procentaj;
              ELSE
--                DBMS_OUTPUT.PUT_LINE(i||' - '||v_bursa);
                  v_newBursa := v_bursa + (lista_studenti(i).procentaj / 100) * v_bursa;
              END IF;


              UPDATE studenti SET bursa = v_newBursa
              WHERE id = lista_studenti(i).id_student;
          END LOOP;
    END marire_bursa; 
END pachet;
/


create procedure export_depending_tables (p_fisier IN UTL_FILE.FILE_TYPE, p_nume_tabela in VARCHAR2) as
    CURSOR v_constraints(p_nume_tabela in VARCHAR2) IS SELECT a.table_name, a.column_name, a.constraint_name, c.owner, 
       -- referenced pk
       c.r_owner, c_pk.table_name r_table_name, c_pk.constraint_name r_pk
      FROM all_cons_columns a
      JOIN all_constraints c ON a.owner = c.owner
                            AND a.constraint_name = c.constraint_name
      JOIN all_constraints c_pk ON c.r_owner = c_pk.owner
                               AND c.r_constraint_name = c_pk.constraint_name
     WHERE c.constraint_type = 'R'
       AND a.table_name = upper(trim(p_nume_tabela));
begin
    for v_line in v_constraints(p_nume_tabela) loop
        redo_this_table_as_well (p_fisier, v_line.r_table_name);
        dbms_output.put_line (v_line.r_table_name);
    end loop;
end export_depending_tables;
/


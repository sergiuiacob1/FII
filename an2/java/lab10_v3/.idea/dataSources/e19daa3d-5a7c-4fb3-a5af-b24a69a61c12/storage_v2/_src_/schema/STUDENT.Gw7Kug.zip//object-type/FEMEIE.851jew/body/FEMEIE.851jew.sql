create TYPE BODY femeie as
    OVERRIDING member procedure gateste AS
    BEGIN
        DBMS_OUTPUT.PUT_LINE ('Am gatit foarte bine!');
    END gateste;

    member procedure naste is
    begin
        DBMS_OUTPUT.PUT_LINE('Am nascut');
    end naste;

    member procedure naste (p_nume_copil VARCHAR2) IS
    begin
        DBMS_OUTPUT.PUT_LINE('Am nascut un copil cu numele ' || p_nume_copil);
    end naste;
END;
/


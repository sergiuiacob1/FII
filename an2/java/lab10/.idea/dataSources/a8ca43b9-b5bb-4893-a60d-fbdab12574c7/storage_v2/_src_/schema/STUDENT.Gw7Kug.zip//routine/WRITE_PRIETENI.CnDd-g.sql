create procedure write_prieteni as
    v_fisier UTL_FILE.FILE_TYPE; 
    v_line_prieteni prieteni%ROWTYPE;
BEGIN
    v_fisier := UTL_FILE.FOPEN('MYDIR', 'prieteni.txt', 'W');
        FOR v_line_prieteni in (select * from prieteni) loop
        utl_file.put_line(v_fisier, v_line_prieteni.id);
        utl_file.put_line(v_fisier, v_line_prieteni.id_student1);
        utl_file.put_line(v_fisier, v_line_prieteni.id_student2);
        utl_file.put_line(v_fisier, v_line_prieteni.created_at);
        utl_file.put_line(v_fisier, v_line_prieteni.updated_at);
--        utl_file.fflush(v_fisier);
        end loop;
    UTL_FILE.FCLOSE(v_fisier);
END write_prieteni;
/


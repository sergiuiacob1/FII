create procedure populeaza_tabele as
    v_i int;
    v_x number (6, 2);
    v_y number (6, 2);
    v_h number (6);
begin
    for v_i in 1..10000000 loop
        v_x := trunc ((DBMS_RANDOM.VALUE (0, 4001)), 2);
        v_y := trunc ((DBMS_RANDOM.VALUE (0, 4001)), 2);
        v_h := trunc (DBMS_RANDOM.VALUE (0, 4001));
        insert into padure values (v_x, v_y, v_h);
    end loop;

    for v_i in 1..10 loop
        v_x := trunc ((DBMS_RANDOM.VALUE (0, 4001)), 2);
        v_y := trunc ((DBMS_RANDOM.VALUE (0, 4001)), 2);
        insert into pozitii values (v_x, v_y);
    end loop;

end populeaza_tabele;

create or replace procedure sterge_tot as
begin
  null;
end sterge_tot;

--CREATE TABLE padure(x NUMBER(6,2), y NUMBER(6,2), h NUMBER(6))
--/
--CREATE TABLE pozitii(x NUMBER(6,2), y NUMBER(6,2))
--/

BEGIN
    ciur();
    populeaza_tabele();

    sterge_tot();
END;
/


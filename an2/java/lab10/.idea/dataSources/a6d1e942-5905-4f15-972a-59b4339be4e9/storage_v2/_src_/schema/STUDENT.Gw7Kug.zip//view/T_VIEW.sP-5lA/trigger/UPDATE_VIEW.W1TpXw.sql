create trigger UPDATE_VIEW
  instead of update
  on T_VIEW
  for each row
  begin
    update items set value = :NEW.value;
end update_view;
/


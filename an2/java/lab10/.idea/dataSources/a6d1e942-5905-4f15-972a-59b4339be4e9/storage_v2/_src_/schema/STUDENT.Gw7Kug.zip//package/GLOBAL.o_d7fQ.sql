create package global as
    TYPE t_array is table of INT index by binary_integer;
end global;
/


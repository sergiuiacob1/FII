create PACKAGE exceptii
AS
    limita_bursa_depasita EXCEPTION;
    PRAGMA EXCEPTION_INIT(limita_bursa_depasita, -20001);
END exceptii;
/


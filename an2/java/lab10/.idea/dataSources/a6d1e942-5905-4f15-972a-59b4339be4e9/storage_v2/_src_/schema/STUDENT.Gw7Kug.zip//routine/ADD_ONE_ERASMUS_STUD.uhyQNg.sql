create FUNCTION add_one_erasmus_stud (p_nr_matricol IN studenti.nr_matricol%TYPE, p_id_tara IN INT)
    RETURN INT
AS
BEGIN
    INSERT INTO erasmus VALUES (p_nr_matricol, p_id_tara);
    RETURN 1;

    EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        RETURN 0;
END add_one_erasmus_stud;
/


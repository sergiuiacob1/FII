create TYPE t_array_burse IS TABLE OF NUMBER(6,2);
/


create PACKAGE lab5 AS
    TYPE t_record IS RECORD(
        id_stud studenti.id%TYPE,
        procent INT
    );
    TYPE t_list_record IS TABLE OF t_record INDEX BY BINARY_INTEGER;
    PROCEDURE mareste_bursa (p_lista_studs IN t_list_record);
    PROCEDURE afiseaza_istoric;
END lab5;
/


create PROCEDURE make_indexes AS
BEGIN
     DBMS_UTILITY.EXEC_DDL_STATEMENT('CREATE INDEX idx_note_id_stud ON note(id_student)');
END make_indexes;
/


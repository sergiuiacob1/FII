create PROCEDURE mareste_bursa (p_id_stud IN studenti.id%TYPE) AS
    v_new_bursa studenti.bursa%TYPE;
BEGIN
    SELECT bursa INTO v_new_bursa FROM studenti WHERE id = p_id_stud;
    v_new_bursa := v_new_bursa + v_new_bursa * 0.5;
    UPDATE studenti SET bursa = v_new_bursa WHERE id = p_id_stud;

    IF (v_new_bursa > 3000) THEN
        v_new_bursa := 3000;
        UPDATE studenti SET bursa = v_new_bursa WHERE id = p_id_stud;
        raise exceptii.limita_bursa_depasita;
    END IF;
END mareste_bursa;
/


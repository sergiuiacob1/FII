create view T_VIEW as
  select p.id_producer, p.nume, i.id_item, i.value from producers p join items i on p.id_producer = i.id_p
/


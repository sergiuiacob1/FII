create procedure select_stud (p_id VARCHAR2) as
    v_nume studenti.nume%TYPE;
begin
    insert into requests values ('aaaa');
--    select nume into v_nume from studenti where id = to_number(p_id);
--    commit;
--    insert into requests values ('Am selectat studentul ' || v_nume);
    commit;
end select_stud;
/


create trigger INSERT_VIEW
  instead of insert
  on T_VIEW
  for each row
  DECLARE
    v_count INT;
begin
    select count(*) into v_count from producers where id_producer = :new.id_producer;
    IF (v_count = 0) THEN
        insert into producers values (:new.id_producer, :new.nume);
    END IF;

    select count(*) into v_count from items where id_item = :new.id_item;
    IF (v_count = 0) THEN
        insert into items values (:new.id_item, :new.value, :new.id_producer);
    END IF;

end insert_view;
/


create procedure insereaza_in_log is
PRAGMA AUTONOMOUS_TRANSACTION;
    v_nextId INT;
    v_username VARCHAR2(100);
begin
    select count(*) + 1 into v_nextId from log_destruction;
    select user into v_username from dual;
    insert into log_destruction values (v_nextId, v_username, sysdate);
    COMMIT;
end insereaza_in_log;
/


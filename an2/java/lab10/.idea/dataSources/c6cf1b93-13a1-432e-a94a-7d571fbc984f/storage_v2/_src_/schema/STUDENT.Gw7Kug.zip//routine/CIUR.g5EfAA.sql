create procedure ciur as
    v_i INT;
    v_j INT;
begin
    global_package.nr_primes := 0;
    global_package.ciurArray := global_package.t_array();
    global_package.primes := global_package.t_array();
    global_package.ciurArray.extend();
    global_package.ciurArray(1) := 0;
    global_package.ciurArray.extend(1000010, 1);
    global_package.primes.extend(100000);
    v_i := 2;
    while (v_i <= 1000000) loop
        if (global_package.ciurArray(v_i) = 0) then
            global_package.nr_primes := global_package.nr_primes + 1;
            global_package.primes(global_package.nr_primes) := v_i;
            v_j := v_i;
            while (v_i * v_j <= 1000000) loop
                global_package.ciurArray(v_i * v_j) := 1;
                v_j := v_j + 1;
            end loop;
        end if;
        v_i := v_i + 1;
    end loop;
end ciur;
/


create function get_om (p_id INT) return om as
    v_om om;
BEGIN
    select col1 into v_om from obj_om where id = p_id;
    return v_om;
END get_om;
/


create PROCEDURE bursa_exceptie (p_id_stud IN studenti.id%TYPE) AS
    v_bursa studenti.bursa%TYPE;
    v_new_istoric studenti.istoric_burse%TYPE;
BEGIN
    SELECT bursa INTO v_bursa FROM studenti WHERE id = p_id_stud;
    SELECT istoric_burse INTO v_new_istoric FROM studenti WHERE id = p_id_stud;
    v_new_istoric.extend();
    v_new_istoric(v_new_istoric.COUNT) := v_bursa;
    UPDATE studenti SET istoric_burse = v_new_istoric WHERE id = p_id_stud;

    mareste_bursa (p_id_stud);

    SELECT bursa INTO v_bursa FROM studenti WHERE id = p_id_stud;
    DBMS_OUTPUT.PUT_LINE ('Studentul ' || p_id_stud || ' primeste bursa ' || v_bursa);
    EXCEPTION
    WHEN exceptii.limita_bursa_depasita THEN
        DBMS_OUTPUT.PUT_LINE ('Studentul ' || p_id_stud || ' a depasit bursa de 3000 de lei. I-au fost dati doar 3000 de lei, ii ajunge');
END bursa_exceptie;
/


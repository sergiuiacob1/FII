create TYPE femeie UNDER om(
    member procedure naste,
    member procedure naste (p_nume_copil VARCHAR2),
    OVERRIDING member procedure gateste
);
/


create PACKAGE facultate AS
    nume_facultate VARCHAR2(50);
    CURSOR lista_studenti IS SELECT nr_matricol, nume, prenume, grupa, an FROM studenti ORDER BY nume;
    PROCEDURE varsta_student (p_id_stud IN INT, v_ani OUT INT, v_luni OUT INT, v_zile OUT INT);
    PROCEDURE adauga_student_random;
    PROCEDURE sterge_student (p_id_stud IN INT);
    PROCEDURE info_student (p_id_stud IN INT);
END facultate;
/


create PACKAGE BODY lab5 AS
    PROCEDURE mareste_bursa(p_lista_studs IN t_list_record) AS
        v_new_istoric_burse studenti.istoric_burse%TYPE;
        v_new_bursa studenti.bursa%TYPE;
    BEGIN
        FOR i in 1..p_lista_studs.COUNT LOOP
            UPDATE studenti SET bursa = 100 WHERE bursa IS NULL AND studenti.id = p_lista_studs(i).id_stud;
        END LOOP;

        FOR i in 1..p_lista_studs.COUNT LOOP
            UPDATE studenti SET bursa = TRUNC((bursa + (bursa * p_lista_studs(i).procent/100))) WHERE studenti.id = p_lista_studs(i).id_stud;
            SELECT istoric_burse INTO v_new_istoric_burse FROM studenti WHERE studenti.id = p_lista_studs(i).id_stud;

            SELECT bursa INTO v_new_bursa FROM studenti WHERE studenti.id = p_lista_studs(i).id_stud;
            v_new_istoric_burse.extend();
            v_new_istoric_burse (v_new_istoric_burse.COUNT) := v_new_bursa;

            UPDATE studenti SET istoric_burse = v_new_istoric_burse WHERE studenti.id = p_lista_studs(i).id_stud;
        END LOOP;
    END mareste_bursa;

    PROCEDURE afiseaza_istoric IS
        --CURSOR are_istoric IS SELECT nume, prenume FROM studenti WHERE studenti.istoric_burse.COUNT > 0;
        v_stud_line studenti%ROWTYPE;
    BEGIN
        FOR v_stud_line IN (SELECT * FROM studenti) LOOP
            CONTINUE WHEN v_stud_line.istoric_burse.COUNT = 0;
             DBMS_OUTPUT.PUT_LINE ('Istoric bursa pentru ' || v_stud_line.nume || ' ' || v_stud_line.prenume);
             FOR i in v_stud_line.istoric_burse.first..v_stud_line.istoric_burse.last LOOP
                DBMS_OUTPUT.PUT_LINE (i || ' ' || v_stud_line.istoric_burse(i));
             END LOOP;
        END LOOP;

        /*OPEN are_istoric;
        LOOP
             FETCH are_istoric INTO v_stud_line;
             EXIT WHEN are_istoric%NOTFOUND;
             DBMS_OUTPUT.PUT_LINE ('Istoric bursa pentru ' || v_stud_line.nume || ' ' || v_stud_line.prenume);
             /*FOR i in v_stud_line.istoric_burse.first..v_stud_line.istoric_burse.last LOOp
                DBMS_OUTPUT.PUT_LINE (i || ' ' || v_stud_line.istoric_burse(i));
             END LOOP;
        END LOOP;
        CLOSE are_istoric;
        */
    END afiseaza_istoric;
END lab5;
/


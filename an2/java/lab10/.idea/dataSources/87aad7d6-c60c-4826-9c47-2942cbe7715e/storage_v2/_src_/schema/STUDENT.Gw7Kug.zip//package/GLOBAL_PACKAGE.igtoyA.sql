create package global_package is
    TYPE t_array is varray(1000030) of INT;
    ciurArray t_array;
    primes t_array;
    nr_primes INT;
end;
/


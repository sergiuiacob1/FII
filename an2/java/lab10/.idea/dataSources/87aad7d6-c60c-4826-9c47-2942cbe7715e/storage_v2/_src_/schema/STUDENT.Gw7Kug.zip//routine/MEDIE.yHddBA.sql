create FUNCTION medie (p_id IN studenti.id%TYPE) RETURN NUMBER AS
    v_medie NUMBER;
BEGIN
    SELECT avg(note.valoare) INTO v_medie
    FROM note
    WHERE note.id_student = p_id;
    RETURN TRUNC(v_medie);
END medie;
/


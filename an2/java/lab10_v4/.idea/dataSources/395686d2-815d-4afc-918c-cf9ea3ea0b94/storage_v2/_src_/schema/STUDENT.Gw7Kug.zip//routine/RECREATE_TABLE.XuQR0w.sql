create procedure recreate_table (p_nume_tabela in VARCHAR2) as
begin
    create_table (p_nume_tabela);
end recreate_table;
/


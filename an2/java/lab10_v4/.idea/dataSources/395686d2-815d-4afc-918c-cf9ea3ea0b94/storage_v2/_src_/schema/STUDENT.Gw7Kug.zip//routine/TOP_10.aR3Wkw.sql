create PROCEDURE top_10 AS
    v_line studenti%ROWTYPE;
    v_bursa studenti.bursa%TYPE;
    v_last_bursa studenti.bursa%TYPE;
    v_marire NUMBER;
    v_i INT;
BEGIN
    v_i := 1;
    FOR v_line IN (SELECT * FROM studenti ORDER BY bursa DESC) LOOP
        CONTINUE WHEN v_line.bursa IS NULL;
        EXIT WHEN v_i > 10;
        v_i := v_i + 1;
        v_bursa := v_line.bursa;
        IF (v_line.istoric_burse.COUNT > 0)
        THEN
            v_last_bursa := v_line.istoric_burse(v_line.istoric_burse.COUNT);
            v_marire := (v_bursa - v_last_bursa)/v_last_bursa;
        ELSE
            v_last_bursa := 0;
            v_marire := 0;
        END IF;
        DBMS_OUTPUT.PUT_LINE ('Stud ' || v_line.id || ' are bursa ' || v_bursa || ' si avea ' || v_last_bursa || ' deci a avut o marire de ' || v_marire);
    END LOOP;
END top_10;
/


create procedure insert_into_table (p_fisier IN UTL_FILE.FILE_TYPE, p_nume_tabela in VARCHAR2) as
    v_cursor_id NUMBER;
    v_ok        NUMBER;
    v_rec_tab     DBMS_SQL.DESC_TAB;
    v_nr_col     NUMBER;
    v_total_coloane     NUMBER;
    v_valori t_array;
    v_i INT;
BEGIN
    v_valori := t_array();
    v_i := 1;
    v_cursor_id  := DBMS_SQL.OPEN_CURSOR;
    DBMS_SQL.PARSE(v_cursor_id , 'SELECT * FROM ' || p_nume_tabela, DBMS_SQL.NATIVE);
    DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, v_total_coloane, v_rec_tab);
    v_valori.extend(v_total_coloane + 1);
    v_nr_col := v_rec_tab.first;
    IF (v_nr_col IS NOT NULL) THEN
        LOOP
            DBMS_SQL.DEFINE_COLUMN(v_cursor_id, v_i, v_valori(v_i), 200);
            v_nr_col := v_rec_tab.next(v_nr_col);
            EXIT WHEN (v_nr_col IS NULL);
            v_i := v_i + 1;
        END LOOP;
    END IF;

    v_ok := DBMS_SQL.EXECUTE(v_cursor_id );
    LOOP 
        IF DBMS_SQL.FETCH_ROWS(v_cursor_id)>0 THEN 
            utl_file.putf (p_fisier, 'insert into ' || p_nume_tabela || ' values (');
            for v_j in 1..v_total_coloane LOOP
                DBMS_SQL.COLUMN_VALUE(v_cursor_id, v_j, v_valori(v_j));
                utl_file.putf (p_fisier, '''' || v_valori(v_j) || '''');
                if (v_j != v_total_coloane) then
                    utl_file.putf (p_fisier, ', ');
                end if;
            END LOOP;
            utl_file.putf (p_fisier, ')\n/\n');
        ELSE 
            EXIT; 
        END IF; 
    END LOOP; 
    DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
END insert_into_table;
/


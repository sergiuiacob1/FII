create PROCEDURE friends AS
    v_medie1 NUMBER;
    v_medie2 NUMBER;
    v_nr_stud INT;
    v_id studenti.id%TYPE;
    v_friend_line prieteni%ROWTYPE;
    type t_array is varray(3000) of NUMBER;
    v_medii t_array := t_array();
BEGIN
    SELECT COUNT(*) INTO v_nr_stud FROM studenti;
    v_medii.extend(v_nr_stud + 1);

    FOR v_id IN (SELECT id FROM studenti) LOOP
        SELECT medie(v_id.id) INTO v_medii(v_id.id) FROM dual;
    END LOOP;

    FOR v_friend_line IN (SELECT * FROM prieteni)
    LOOP
        v_medie1 := v_medii(v_friend_line.id_student1);
        v_medie2 := v_medii(v_friend_line.id_student2);
        IF (v_medie1 = v_medie2) THEN
            DBMS_OUTPUT.PUT_LINE (v_friend_line.id_student1 || ' ' || v_friend_line.id_student2);
        END IF;
    END LOOP;
END friends;
/


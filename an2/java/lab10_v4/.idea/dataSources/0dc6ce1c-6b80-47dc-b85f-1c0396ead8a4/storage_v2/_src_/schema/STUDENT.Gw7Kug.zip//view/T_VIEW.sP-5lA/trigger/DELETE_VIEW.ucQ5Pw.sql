create trigger DELETE_VIEW
  instead of delete
  on T_VIEW
  for each row
  begin
--    dbms_output.put_line ('old id p: ' || :OLD.id_producer);
    delete from items where id_item = :OLD.id_item or id_p = :OLD.id_producer;
    delete from producers where id_producer = :OLD.id_producer;
end update_view;
/


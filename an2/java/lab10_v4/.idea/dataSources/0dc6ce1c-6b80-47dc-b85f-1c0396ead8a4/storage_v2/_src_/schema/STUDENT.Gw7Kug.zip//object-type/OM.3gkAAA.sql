create type om as object (
    nume VARCHAR2 (20),
    prenume VARCHAR2 (20),
    varsta INT,
    sex VARCHAR2 (10),
    CONSTRUCTOR function om (p_nume varchar2, p_prenume varchar2, p_varsta int) RETURN SELF AS RESULT,
    NOT FINAL member procedure gateste,
    member procedure info,
    ORDER member function omsort (p_om2 om) return number
) NOT FINAL;
/


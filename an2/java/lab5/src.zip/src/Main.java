import view.CatalogFrame;

public class Main {
    public static void main (String args[]){
        CatalogFrame catalogFrame = new CatalogFrame("tree");
        catalogFrame.start();
    }
}

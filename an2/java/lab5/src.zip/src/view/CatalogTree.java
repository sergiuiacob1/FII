package view;

import com.sun.xml.internal.ws.util.StringUtils;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class CatalogTree extends JTree implements java.io.Serializable {
    private DefaultMutableTreeNode top;
    private static int nrNodes = 0;

    public CatalogTree() {
        super(new DefaultMutableTreeNode("Catalog Documents"));
        top = (DefaultMutableTreeNode)this.getModel().getRoot();
    }

    public void addDocument (String item){
        DefaultMutableTreeNode newNode;
        this.nrNodes++;
        newNode = new DefaultMutableTreeNode("Document " + String.valueOf(this.nrNodes));
        top.add(newNode);
        String []parts = item.split(" |,|\\[|\\]");
        newNode.add(new DefaultMutableTreeNode("Name: " + parts[0]));
        newNode.add(new DefaultMutableTreeNode("Year: " + parts[2]));
        newNode.add(new DefaultMutableTreeNode("Path: " + parts[3]));
        reload();
    }

    public void reload(){
        ((DefaultTreeModel)this.getModel()).reload();
    }
}

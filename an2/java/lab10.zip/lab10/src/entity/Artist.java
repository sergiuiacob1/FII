package entity;

public class Artist {
}

package entity;

public class Album {
}

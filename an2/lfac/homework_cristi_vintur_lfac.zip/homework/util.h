#include <string.h>

#ifndef UTIL_H
#define UTIL_H

#define BOOL_t -1
#define CHAR_t -2
#define SHORT_t -3
#define INT_t -4
#define LONG_t -5
#define FLOAT_t -6
#define DOUBLE_t -7
#define STRING_t -8
#define VOID_t -9
#define ERROR_t -1000

union value {
	int intval;
	char charval;
	long long longval;
	short shortval;
	float floatval;
	double doubleval;
	char* strval;
};

struct variable {
	char *name;
	int type, initialized, dimens;
	union value val;
};

struct info {
	int type;
	union value val;
};

struct function {
	char *name;
	int return_type, defined;
	char *parameters_type;
};

struct userStruct {
	char *name, *members[10];
	int numMembers, types[10], dimens[10];
};

int numVars, numFuncts, numStructs;
char s[10000];
struct variable vars[1000];
struct userStruct structs[1000];
struct function funct[1000];

void strAssign1(char **dst, char *src);
void strAssign2(char **dst, char *src1, char *src2);
void strAssign3(char **dst, char *src, char *src2, char *src3);
void strAppend(char **dst, char *str);

int isLetter(char c);

char* parseString(char *s);
double exponentialNot(char *s);
char* my_itoa(int val);
int addVar(char *name, int type, char *structName);
struct info getVar(char *name);
int getVarType(char *name);
void markInitialized(char *name);
int varExists(char *name);
void addDimens(char *name, char *structName);

int addStruct(char *name);
int addStructMember(char *structName, char *name, int type);
void addStructDimens(char *structName, char *name);
int structExists(char *name);
int structType(char *name);
int structGetType(int structNum, char *name);

int addFunction(char *name, int return_type, char *parameters_type, int declared);
int getReturnType(char *name, char *parameters_type);
int checkFunctionParams(char *name, char *parameters_type);

struct info plusOP(struct info a, struct info b);
struct info minusOP(struct info a, struct info b);
struct info mulOP(struct info a, struct info b);
struct info divOP(struct info a, struct info b);
struct info modOP(struct info a, struct info b);
struct info equalOP(struct info a, struct info b);
struct info notEqualOP(struct info a, struct info b);
struct info lessOP(struct info a, struct info b);
struct info lessEqOP(struct info a, struct info b);
struct info greaterOP(struct info a, struct info b);
struct info greaterEqOP(struct info a, struct info b);
struct info logicalAndOP(struct info a, struct info b);
struct info logicalOrOP(struct info a, struct info b);
int assignOP(char *name, struct info b);

char* valueToString(struct info a);

#endif
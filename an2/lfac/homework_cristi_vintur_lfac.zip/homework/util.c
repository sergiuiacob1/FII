#include "util.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

void strAssign1(char **dst, char *src) {
	*dst = (char*) malloc(sizeof(char) * (strlen(src) + 1));
	strcpy(*dst, src);
}

void strAssign2(char **dst, char *src1, char *src2) {
	*dst = (char*) malloc(sizeof(char) * (strlen(src1) + strlen(src2) + 1));
	strcpy(*dst, src1);
	strcat(*dst, src2);
}

void strAssign3(char **dst, char *src1, char *src2, char *src3) {
	*dst = (char*) malloc(sizeof(char) * (strlen(src1) + strlen(src2) + strlen(src3) + 1));
	strcpy(*dst, src1);
	strcat(*dst, src2);
	strcat(*dst, src3);
}

void strAppend(char **dst, char *str) {
	char *s = *dst;
	
	*dst = (char*) malloc(sizeof(char) * (strlen(*dst) + strlen(str) + 1));
	strcpy(*dst, s);
	strcat(*dst, str);
}

int isLetter(char c) {
	return ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') || ('0' <= c && c <= '9') || c == '_';
}

char* parseString(char *s) {
	int i, j;
	
	for(i = j = 1; s[i]; ++i) {
		if(s[i + 1] == '\0') {
			s[j] = '\0';
			return strdup(s + 1);
		}
		
		if(s[i] == '\\') {
			switch(s[i + 1]) {
				case 'a': s[j++] = '\a'; ++i; break;
				case 'b': s[j++] = '\b'; ++i; break;
				case 'e': s[j++] = '\e'; ++i; break;
				case 'f': s[j++] = '\f'; ++i; break;
				case 'n': s[j++] = '\n'; ++i; break;
				case 'r': s[j++] = '\r'; ++i; break;
				case 't': s[j++] = '\t'; ++i; break;
				case 'v': s[j++] = '\v'; ++i; break;
				case '\'': s[j++] = '\''; ++i; break;
				case '\"': s[j++] = '\"'; ++i; break;
				case '\\': s[j++] = '\\'; ++i; break;
				default: return NULL;
			}
		} else {
			s[j++] = s[i];
		}
	}
	
	return NULL;
}

double exponentialNot(char *s) {
	int i, sign;
	double mul, e;
	
	for(mul = 0, i = 0; '0' <= s[i] && s[i] <= '9'; ++i)
		mul = mul * 10 + s[i] - '0';
	
	++i;
	if(s[i] == '+') sign = 1, ++i;
	else if(s[i] == '-') sign = -1, ++i;
	else sign = 1;
	
	for(e = 0; '0' <= s[i] && s[i] <= '9'; ++i)
		e = e * 10 + s[i] - '0';
	
	return mul * pow(10.0, sign * e);
}

char* my_itoa(int val)
{
  sprintf(s, "%d", val);
  return s;
}

int addVar(char *name, int type, char *structName) {
	//printf("var %s struct %s type %d\n", name, structName, type);
	if(!structName) {
		for(int i = 0; i < numVars; ++i)
			if(strcmp(vars[i].name, name) == 0)
				return 0;
		
		//printf("new var %s of type %d\n", name, type);
		
		strAssign1(&vars[numVars].name, name);
		vars[numVars].type = type;
		vars[numVars].dimens = 0;
		++numVars;
	
		return 1;
	}
	
	return addStructMember(structName, name, type);
}

struct info getVar(char *name) {
	int i, dimens;
	struct info ret;
	
	for(i = 0; isLetter(name[i]); ++i);
	
	if(name[i] != '\0') {
		ret.type = getVarType(name);
		memset(&ret.val, 0, sizeof ret.val);
	} else {
		for(int i = 0; i < numVars; ++i)
			if(strcmp(vars[i].name, name) == 0) {
				ret.type = vars[i].type;
				ret.val = vars[i].val;
			}
	}
	
	return ret;
}

int getVarType(char *name) {
	//printf("vartype: %s ", name);
	int ii, dimens;
	char *base = (char*) malloc(sizeof(char) * (strlen(name) + 1));
	
	//printf("getvartype: %s ", name);
	
	for(ii = 0; isLetter(name[ii]); ++ii)
		base[ii] = name[ii];
	base[ii] = '\0';
	
	for(dimens = 0; name[ii] == '['; ii += 2, ++dimens);
	
	for(int i = 0; i < numVars; ++i)
		if(strcmp(vars[i].name, base) == 0) {
			if(vars[i].dimens == dimens) {
				if(!name[ii]) return vars[i].type;
				return structGetType(vars[i].type, name + ii + 1);
			}
			else return ERROR_t;
		}
	
	return ERROR_t;
}

void markInitialized(char *name) {
	for(int i = 0; i < numVars; ++i)
		if(strcmp(vars[i].name, name) == 0) {
			vars[i].initialized = 1;
			return;
		}
}

int varExists(char *name) {
	return getVarType(name) != ERROR_t;
}

void addDimens(char *name, char *structName) {
	if(!structName) {
		for(int i = 0; i < numVars; ++i)
			if(strcmp(vars[i].name, name) == 0)
				++vars[i].dimens;
	} else addStructDimens(structName, name);
}

int addStruct(char *name) {
	for(int i = 0; i < numStructs; ++i)
		if(strcmp(structs[i].name, name) == 0)
			return 0;
	
	strAssign1(&structs[numStructs].name, name);
	++numStructs;
	
	return 1;
}

int addStructMember(char *structName, char *name, int type) {
	for(int i = 0; i < numStructs; ++i)
		if(strcmp(structs[i].name, structName) == 0) {
			for(int j = 0; j < structs[i].numMembers; ++j)
				if(strcmp(structs[i].members[j], name) == 0)
					return 0;
			
			strAssign1(&structs[i].members[structs[i].numMembers], name);
			structs[i].types[structs[i].numMembers] = type;
			++structs[i].numMembers;
			return 1;
		}
	
	return 0;
}

void addStructDimens(char *structName, char *name) {
	for(int i = 0; i < numStructs; ++i)
		if(strcmp(structs[i].name, structName) == 0) {
			for(int j = 0; j < structs[i].numMembers; ++j)
				if(strcmp(structs[i].members[j], name) == 0) {
					++structs[i].dimens[j];
					return;
				}
		}
}

int structExists(char *name) {
	for(int i = 0; i < numStructs; ++i)
		if(strcmp(structs[i].name, name) == 0)
			return 1;
	
	return 0;
}

int structType(char *name) {
	//printf("struct type check %s: ", name);
	for(int i = 0; i < numStructs; ++i)
		if(strcmp(structs[i].name, name) == 0)
			return i;
	
	return ERROR_t;
}

int structGetType(int structNum, char *name) {
	if(structNum < 0) return ERROR_t;
	
	int i, dimens;
	char *base = malloc(sizeof(char) * (strlen(name) + 1));
	
	for(i = 0; isLetter(name[i]); ++i) base[i] = name[i];
	base[i] = '\0';
	
	for(dimens = 0; name[i] == '['; i += 2, ++dimens);
	
	for(int j = 0; j < structs[structNum].numMembers; ++j) {
		if(strcmp(structs[structNum].members[j], base) == 0 && structs[structNum].dimens[j] == dimens) {
			if(!name[i]) return structs[structNum].types[j];
			return structGetType(structs[structNum].types[j], name + i + 1);
		}
	}
	
	return ERROR_t;
}

int addFunction(char *name, int return_type, char *parameters_type, int defined)
{
	for(int i = 0; i < numFuncts; ++i)
		if(strcmp(funct[i].name, name) == 0 && strcmp(parameters_type, funct[i].parameters_type) == 0) {
			if(defined == 0) return 0;
			if(funct[i].defined) return 0;
			if(return_type != funct[i].return_type) return 0;
			
			funct[i].defined = 1;
			return 1;
		}
	
	//printf("new func: %s %d %s\n", name, return_type, parameters_type);
	
	strAssign1(&funct[numFuncts].name, name);
	funct[numFuncts].return_type = return_type;
	strAssign1(&funct[numFuncts].parameters_type, parameters_type);
	funct[numFuncts].defined = defined;
	++numFuncts;
	
	return 1;
}

int getReturnType(char *name, char *parameters_type) {
	for(int i = 0; i < numFuncts; ++i)
		if(strcmp(funct[i].name, name) == 0 && strcmp(parameters_type, funct[i].parameters_type) == 0)
			return funct[i].return_type;
	
	return 0;
}

int checkFunctionParams(char *name, char *parameters_type) {
	//printf("check func: %s\n", parameters_type);
	for(int i = 0; i < numFuncts; ++i)
		if(strcmp(funct[i].name, name) == 0 && strcmp(parameters_type, funct[i].parameters_type) == 0)
			return 1;
	
	return 0;
}

struct info plusOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = a.type;
		
		switch(a.type) {
			case INT_t: ret.val.intval = a.val.intval + b.val.intval; break;
			case BOOL_t: ret.val.intval = a.val.intval | b.val.intval; break;
			case CHAR_t: ret.val.charval = a.val.charval + b.val.charval; break;
			case LONG_t: ret.val.longval = a.val.longval + b.val.longval; break;
			case SHORT_t: ret.val.shortval = a.val.shortval + b.val.shortval; break;
			case FLOAT_t: ret.val.floatval = a.val.floatval + b.val.floatval; break;
			case DOUBLE_t: ret.val.doubleval = a.val.doubleval + b.val.doubleval; break;
			case STRING_t: strAssign1(&ret.val.strval, a.val.strval); strAppend(&ret.val.strval, b.val.strval); break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info minusOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = a.type;
		
		switch(a.type) {
			case INT_t: ret.val.intval = a.val.intval - b.val.intval; break;
			case CHAR_t: ret.val.charval = a.val.charval - b.val.charval; break;
			case LONG_t: ret.val.longval = a.val.longval - b.val.longval; break;
			case SHORT_t: ret.val.shortval = a.val.shortval - b.val.shortval; break;
			case FLOAT_t: ret.val.floatval = a.val.floatval - b.val.floatval; break;
			case DOUBLE_t: ret.val.doubleval = a.val.doubleval - b.val.doubleval; break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info mulOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = a.type;
		
		switch(a.type) {
			case INT_t: ret.val.intval = a.val.intval * b.val.intval; break;
			case BOOL_t: ret.val.intval = a.val.intval & b.val.intval; break;
			case CHAR_t: ret.val.charval = a.val.charval * b.val.charval; break;
			case LONG_t: ret.val.longval = a.val.longval * b.val.longval; break;
			case SHORT_t: ret.val.shortval = a.val.shortval * b.val.shortval; break;
			case FLOAT_t: ret.val.floatval = a.val.floatval * b.val.floatval; break;
			case DOUBLE_t: ret.val.doubleval = a.val.doubleval * b.val.doubleval; break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info divOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = a.type;
		
		switch(a.type) {
			case INT_t: ret.val.intval = a.val.intval / b.val.intval; break;
			case CHAR_t: ret.val.charval = a.val.charval / b.val.charval; break;
			case LONG_t: ret.val.longval = a.val.longval / b.val.longval; break;
			case SHORT_t: ret.val.shortval = a.val.shortval / b.val.shortval; break;
			case FLOAT_t: ret.val.floatval = a.val.floatval / b.val.floatval; break;
			case DOUBLE_t: ret.val.doubleval = a.val.doubleval / b.val.doubleval; break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info modOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = a.type;
		
		switch(a.type) {
			case INT_t: ret.val.intval = a.val.intval % b.val.intval; break;
			case CHAR_t: ret.val.charval = a.val.charval % b.val.charval; break;
			case LONG_t: ret.val.longval = a.val.longval % b.val.longval; break;
			case SHORT_t: ret.val.shortval = a.val.shortval % b.val.shortval; break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info equalOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = BOOL_t;
		
		switch(a.type) {
			case BOOL_t: ret.val.intval = (a.val.intval == b.val.intval); break;
			case CHAR_t: ret.val.charval = (a.val.charval == b.val.charval); break;
			case SHORT_t: ret.val.shortval = (a.val.shortval == b.val.shortval); break;
			case INT_t: ret.val.intval = (a.val.intval == b.val.intval); break;
			case LONG_t: ret.val.longval = (a.val.longval == b.val.longval); break;
			case FLOAT_t: ret.val.floatval = (a.val.floatval == b.val.floatval); break;
			case DOUBLE_t: ret.val.doubleval = (a.val.doubleval == b.val.doubleval); break;
			case STRING_t: ret.val.intval = (strcmp(a.val.strval, b.val.strval) == 0); break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info notEqualOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = BOOL_t;
		
		switch(a.type) {
			case BOOL_t: ret.val.intval = (a.val.intval != b.val.intval); break;
			case CHAR_t: ret.val.charval = (a.val.charval != b.val.charval); break;
			case SHORT_t: ret.val.shortval = (a.val.shortval != b.val.shortval); break;
			case INT_t: ret.val.intval = (a.val.intval != b.val.intval); break;
			case LONG_t: ret.val.longval = (a.val.longval != b.val.longval); break;
			case FLOAT_t: ret.val.floatval = (a.val.floatval != b.val.floatval); break;
			case DOUBLE_t: ret.val.doubleval = (a.val.doubleval != b.val.doubleval); break;
			case STRING_t: ret.val.intval = (strcmp(a.val.strval, b.val.strval) != 0); break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info lessOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = BOOL_t;
		
		switch(a.type) {
			case BOOL_t: ret.val.intval = (a.val.intval < b.val.intval); break;
			case CHAR_t: ret.val.charval = (a.val.charval < b.val.charval); break;
			case SHORT_t: ret.val.shortval = (a.val.shortval < b.val.shortval); break;
			case INT_t: ret.val.intval = (a.val.intval < b.val.intval); break;
			case LONG_t: ret.val.longval = (a.val.longval < b.val.longval); break;
			case FLOAT_t: ret.val.floatval = (a.val.floatval < b.val.floatval); break;
			case DOUBLE_t: ret.val.doubleval = (a.val.doubleval < b.val.doubleval); break;
			case STRING_t: ret.val.intval = (strcmp(a.val.strval, b.val.strval) < 0); break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info lessEqOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = BOOL_t;
		
		switch(a.type) {
			case BOOL_t: ret.val.intval = (a.val.intval <= b.val.intval); break;
			case CHAR_t: ret.val.charval = (a.val.charval <= b.val.charval); break;
			case SHORT_t: ret.val.shortval = (a.val.shortval <= b.val.shortval); break;
			case INT_t: ret.val.intval = (a.val.intval <= b.val.intval); break;
			case LONG_t: ret.val.longval = (a.val.longval <= b.val.longval); break;
			case FLOAT_t: ret.val.floatval = (a.val.floatval <= b.val.floatval); break;
			case DOUBLE_t: ret.val.doubleval = (a.val.doubleval <= b.val.doubleval); break;
			case STRING_t: ret.val.intval = (strcmp(a.val.strval, b.val.strval) <= 0); break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info greaterOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = BOOL_t;
		
		switch(a.type) {
			case BOOL_t: ret.val.intval = (a.val.intval > b.val.intval); break;
			case CHAR_t: ret.val.charval = (a.val.charval > b.val.charval); break;
			case SHORT_t: ret.val.shortval = (a.val.shortval > b.val.shortval); break;
			case INT_t: ret.val.intval = (a.val.intval > b.val.intval); break;
			case LONG_t: ret.val.longval = (a.val.longval > b.val.longval); break;
			case FLOAT_t: ret.val.floatval = (a.val.floatval > b.val.floatval); break;
			case DOUBLE_t: ret.val.doubleval = (a.val.doubleval > b.val.doubleval); break;
			case STRING_t: ret.val.intval = (strcmp(a.val.strval, b.val.strval) > 0); break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info greaterEqOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type) ret.type = ERROR_t;
	else {
		ret.type = BOOL_t;
		
		switch(a.type) {
			case BOOL_t: ret.val.intval = (a.val.intval >= b.val.intval); break;
			case CHAR_t: ret.val.charval = (a.val.charval >= b.val.charval); break;
			case SHORT_t: ret.val.shortval = (a.val.shortval >= b.val.shortval); break;
			case INT_t: ret.val.intval = (a.val.intval >= b.val.intval); break;
			case LONG_t: ret.val.longval = (a.val.longval >= b.val.longval); break;
			case FLOAT_t: ret.val.floatval = (a.val.floatval >= b.val.floatval); break;
			case DOUBLE_t: ret.val.doubleval = (a.val.doubleval >= b.val.doubleval); break;
			case STRING_t: ret.val.intval = (strcmp(a.val.strval, b.val.strval) >= 0); break;
			default: ret.type = ERROR_t;
		}
	}
	
	return ret;
}

struct info logicalAndOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type || a.type != BOOL_t) ret.type = ERROR_t;
	else {
		ret.type = BOOL_t;
		ret.val.intval = (a.val.intval && b.val.intval);
	}
	
	return ret;
}

struct info logicalOrOP(struct info a, struct info b) {
	struct info ret;
	
	if(a.type != b.type || a.type != BOOL_t) ret.type = ERROR_t;
	else {
		ret.type = BOOL_t;
		ret.val.intval = (a.val.intval || b.val.intval);
	}
	
	return ret;
}

int assignOP(char *name, struct info b) {	
	if(getVarType(name) != b.type) return 0;
	
	for(int i = 0; i < numVars; ++i)
		if(strcmp(vars[i].name, name) == 0) {
			vars[i].val = b.val;
		}
	
	return 1;
}

char* valueToString(struct info a) {
	switch(a.type) {
		case INT_t: sprintf(s, "%d\n", a.val.intval); break;
		case BOOL_t: sprintf(s, "%d\n", a.val.intval); break;
		case CHAR_t: sprintf(s, "%c\n", a.val.charval); break;
		case LONG_t: sprintf(s, "%lld\n", a.val.longval); break;
		case SHORT_t: sprintf(s, "%d\n", (int)a.val.shortval); break;
		case FLOAT_t: sprintf(s, "%f\n", a.val.floatval); break;
		case DOUBLE_t: sprintf(s, "%lf\n", a.val.doubleval); break;
		case STRING_t: sprintf(s, "%s\n", a.val.strval); break;
		default: return NULL;
	}
	
	return s;
}